﻿using LUB4C.Models;
using Newtonsoft.Json;
using Profisee.MasterDataMaestro.Services.DataContracts;
using Profisee.MasterDataMaestro.Services.DataContracts.MasterDataServices;
using Profisee.MasterDataMaestro.Services.MessageContracts;
using Profisee.Services.Sdk.AcceleratorFramework;
using Profisee.Services.Sdk.Common.Contracts.DataContext;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Configuration;
using System.Dynamic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Web.Http;
using System.Web.Mvc;
using MdmAttribute = Profisee.MasterDataMaestro.Services.DataContracts.MasterDataServices.Attribute;

namespace LUB4C.Controllers
{
    public class ValuesController : ApiController
    {
        // GET api/values/5
        public string Get(int id)
        {
            string jsonMembers = "{'animals':['majestic badger','fluffy bunny','scary bear','chicken']}";
            return jsonMembers;
        }

        // GET api/values?data={\"requestIdentifier\":\"fieldRequestIdentifier\",\"columns\":[{\"name\":\"Name\",\"value\":\"First Financial\"},{\"name\":\"Billing Address\",\"value\":\"255 East Fifth Street\"},{\"name\":\"Billing Postal Code\",\"value\":\"45202\"}],\"search\":{\"model\":\"Salesforce\",\"entity\":\"Account\",\"version\":\"VERSION_1\",\"strategy\":\"Salesforce Account\"}}
        public JsonResult Get(string data)
        {
            data = data.Replace("\\", string.Empty);
            MatchRequest matchRequest = JsonConvert.DeserializeObject<MatchRequest>(data);

            JsonResult jsonResult = null;
            if (matchRequest.requestIdentifier.StartsWith("lookup", StringComparison.CurrentCultureIgnoreCase))
            {
                List<dynamic> matchedMembers = GetMatchMembers(matchRequest);

                string jsonData = JsonConvert.SerializeObject(matchedMembers, Newtonsoft.Json.Formatting.None);

                jsonResult = new JsonResult() { Data = jsonData, JsonRequestBehavior = JsonRequestBehavior.AllowGet };
            }
            else if(matchRequest.requestIdentifier.StartsWith("trigger", StringComparison.CurrentCultureIgnoreCase))
            {
                TriggerMember(matchRequest);
            }

            return jsonResult;
        }

        private void TriggerMember(MatchRequest triggerRequest)
        {
            string maestroURI = ConfigurationManager.AppSettings.Get("MaestroURI");
            string maestroCreateCode = ConfigurationManager.AppSettings.Get("GenerateMaestroCode");

            MdmSource mdmSource = new MdmSource();
            mdmSource.Connect(maestroURI);

            MdmModel mdmModel = mdmSource.GetModel(triggerRequest.search.model);

            MdmEntity mdmEntity = mdmModel.GetEntity(triggerRequest.search.entity);

            LookupColumn lookupColumnName = triggerRequest.columns.FirstOrDefault(x => x.name == "Name");
            LookupColumn lookupColumnSalesforceID = triggerRequest.columns.FirstOrDefault(x => x.name == "SalesforceID");

            BrowseEntityContext browseEntityContext = new BrowseEntityContext()
            {
                IdentityOnly = false,
                PageSize = 100,
                MemberType = MemberType.Leaf,
                Filter = "[SalesforceID]='" + lookupColumnSalesforceID.value + "'"
            };

            Collection<MdmMember> mdmMembers = mdmEntity.GetMdmMembers(triggerRequest.search.version, browseEntityContext);
            if ((null != mdmMembers) && (mdmMembers.Count > 0))
            {
                foreach(MdmMember mdmMember in mdmMembers)
                {
                    mdmMember.SetMemberValue("SalesforceState", "Update");
                    mdmMember.Update();
                }
            }
            else if ((null != mdmMembers) && (mdmMembers.Count < 1))
            {
                MdmMember mdmMember = mdmEntity.GetNewMdmMemberTemplate(triggerRequest.search.version, MemberType.Leaf);

                if (maestroCreateCode.Equals("true", StringComparison.CurrentCultureIgnoreCase))
                    mdmMember.Code = Guid.NewGuid().ToString();

                mdmMember.Name = lookupColumnName.value;
                mdmMember.SetMemberValue("SalesforceID", lookupColumnSalesforceID.value);
                mdmMember.SetMemberValue("SalesforceState", "Create");

                mdmMember.Add();
            }
        }
        private List<dynamic> GetMatchMembers(MatchRequest matchRequest)
        {
            MdmSource mdmSource = new MdmSource();

            string maestroURI = ConfigurationManager.AppSettings.Get("MaestroURI");
            mdmSource.Connect(maestroURI);

            MdmModel mdmModel = mdmSource.GetModel(matchRequest.search.model);

            MdmEntity mdmEntity = mdmModel.GetEntity(matchRequest.search.entity);

            MatchingStrategy matchingStrategy = mdmModel.GetMatchingStrategy(matchRequest.search.strategy);

            Member matchMember = BuildMatchMember(matchingStrategy.ColumnSets, mdmEntity.LeafAttributes, matchRequest.columns);

            GetMemberMatchesResponse response = GetMemberMatches(matchMember, matchingStrategy, mdmModel);

            Collection<MdmMember> mdmMembers = GetCompleteMatchedMembers(matchRequest, mdmEntity, response);

            List<dynamic> allMembers = GetDynamicMembers(response, mdmMembers);

            return allMembers;
        }
        private Member BuildMatchMember(Collection<MatchingStrategyDetailSet> matchingStrategyDetailSet, Collection<MetadataAttribute> metadataAttributes, List<LookupColumn> columns)
        {
            Member member = new Member()
            {
                Parents = new Collection<Parent>(),
                MemberId = new MemberIdentifier(),
                Attributes = new Collection<MdmAttribute>()
            };

            #region Get a complete and distinct list of the matching strategy attributes
            Collection<MetadataAttribute> allMetadataAttributes = new Collection<MetadataAttribute>();
            foreach (MatchingStrategyDetailSet columnset in matchingStrategyDetailSet)
            {
                foreach (MatchingStrategyDetail column in columnset.Columns)
                {
                    allMetadataAttributes.Add(metadataAttributes.FirstOrDefault(x => x.Name == column.Identifier.Name));
                }
            }
            List<MetadataAttribute> distinctMetadataAttributes = allMetadataAttributes.Distinct().ToList();
            #endregion

            #region add the attributes and their values to the search member
            foreach (MetadataAttribute attribute in distinctMetadataAttributes)
            {
                string attributeValue = string.Empty;
                LookupColumn lookupColumn = columns.FirstOrDefault(x => x.name == attribute.Name);
                if (null != lookupColumn)
                    attributeValue = lookupColumn.value;

                member.Attributes.Add(new MdmAttribute()
                {
                    Identifier = new Identifier() { Name = attribute.Name },
                    Value = attributeValue,
                    Type = (AttributeValueType)attribute.AttributeType
                });
            }
            #endregion

            return member;
        }
        private GetMemberMatchesResponse GetMemberMatches(List<Member> memberList, MatchingStrategy matchingStrategy, MdmModel mdmModel)
        {
            GetMemberMatchesRequest request = new GetMemberMatchesRequest()
            {
                StrategyId = matchingStrategy.Identifier,
                IncludeMatchesInMemberGroups = true,
                Members = memberList
            };

            GetMemberMatchesResponse getMemberMatchesResponse = mdmModel.GetMemberMatches(request);

            return getMemberMatchesResponse;
        }
        private GetMemberMatchesResponse GetMemberMatches(Member member, MatchingStrategy matchingStrategy, MdmModel mdmModel)
        {
            List<Member> memberList = new List<Member>();
            memberList.Add(member);

            return GetMemberMatches(memberList, matchingStrategy, mdmModel);
        }
        private Collection<MdmMember> GetCompleteMatchedMembers(MatchRequest matchRequest, MdmEntity mdmEntity, GetMemberMatchesResponse response)
        {
            Collection<MdmMember> mdmMembers = new Collection<MdmMember>();
            if (response.Members.Count > 0)
            {
                if (response.Members[0].MatchedMembers.Count > 0)
                {
                    List<string> matchedMembers = new List<string>();
                    foreach (MemberMatchesResultDetail memberDetail in response.Members[0].MatchedMembers)
                        matchedMembers.Add(memberDetail.Code);

                    mdmMembers = GetMembers(matchedMembers, mdmEntity, matchRequest.search.version);
                }
            }

            return mdmMembers;
        }
        private Collection<MdmMember> GetMembers(List<string> memberCodes, MdmEntity mdmEntity, string version)
        {
            string codes = string.Join("','", memberCodes);

            BrowseEntityContext browseEntityContext = new BrowseEntityContext()
            {
                Filter = "Code in ('" + codes + "')",
                IdentityOnly = false,
                MemberType = MemberType.Leaf
            };

            Collection<string> attributeNames = null;
            Collection<MdmMember> members = mdmEntity.GetMdmMembers(version, browseEntityContext, attributeNames);

            return members;
        }
        private List<dynamic> GetDynamicMembers(GetMemberMatchesResponse response, Collection<MdmMember> mdmMembers)
        {
            List<dynamic> allMembers = new List<dynamic>();
            foreach (MdmMember mdmMember in mdmMembers)
            {
                MemberMatchesResultDetail matchedMember = response.Members[0].MatchedMembers.FirstOrDefault(m => m.Code == mdmMember.Code);

                dynamic dynamicMember = BuildDynamicMdmMember(mdmMember, matchedMember);
                allMembers.Add(dynamicMember);
            }

            // sort the list by match score
            allMembers = allMembers.OrderByDescending(x => ((IDictionary<string, object>)x)["Match Score"]).ToList();
            return allMembers;
        }
        private dynamic BuildDynamicMdmMember(MdmMember mdmMember, MemberMatchesResultDetail matchedMember)
        {
            var member = new ExpandoObject() as IDictionary<string, Object>;

            member.Add("Name", mdmMember.Name);

            member.Add("Code", mdmMember.Code);

            foreach (MdmAttribute memberAttribute in mdmMember.Member.Attributes)
            {
                if (null == memberAttribute.Value)
                {
                    member.Add(memberAttribute.Name, "");
                }
                else if (memberAttribute.Name == "Match Score") // use the match call score not the group score
                {
                    member.Add(memberAttribute.Name, matchedMember.Score.ToString());
                }
                else
                {
                    if (memberAttribute.Type == AttributeValueType.Domain)
                    {
                        string value = string.Empty;

                        MemberIdentifier memberIdentifier = (MemberIdentifier)memberAttribute.Value;
                        if (null == memberIdentifier.Name && null == memberIdentifier.Code)
                            value = "";
                        else if (memberIdentifier.Name == null)
                            value = memberIdentifier.Code + "[]";
                        else
                            value = memberIdentifier.Code + "[" + memberIdentifier.Name + "]";

                        member.Add(memberAttribute.Name, value);
                    }
                    else
                    {
                        member.Add(memberAttribute.Name, memberAttribute.Value.ToString());
                    }
                }
            }

            return member;
        }
    }
}
