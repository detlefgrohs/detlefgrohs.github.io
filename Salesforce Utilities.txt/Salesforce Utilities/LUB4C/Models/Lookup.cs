﻿using Newtonsoft.Json;
using Profisee.MasterDataMaestro.Services.DataContracts.MasterDataServices;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace LUB4C.Models
{
    public class LookupColumn
    {
        public string name { get; set; }
        public AttributeValueType type { get; set; }
        public string value { get; set; }
        public string defaultValue { get; set; }
        public bool orderable { get; set; }
        public bool searchable { get; set; }
        public string width { get; set; }
    }
    public class LookupSearch
    {
        public string model { get; set; }
        public string entity { get; set; }
        public string version { get; set; }
        public string strategy { get; set; }
    }
    public class MatchRequest
    {
        [JsonProperty("requestIdentifier")]
        public string requestIdentifier { get; set; }
        public List<LookupColumn> columns { get; set; }
        public LookupSearch search { get; set; }

    }

    public class TriggerRequest
    {
        [JsonProperty("requestIdentifier")]
        public string requestIdentifier { get; set; }
        public LookupSearch trigger { get; set; }

    }

    public class MemberRequest
    {
        public List<string> codes { get; set; }
        public string requestIdentifier { get; set; }
        public LookupColumn[] columns { get; set; }
        public LookupSearch search { get; set; }

    }
}