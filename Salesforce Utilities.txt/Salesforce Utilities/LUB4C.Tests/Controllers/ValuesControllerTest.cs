﻿using LUB4C.Controllers;
using LUB4C.Models;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Collections.Generic;

using Newtonsoft.Json;
using System.Web.Http.Results;
using System.Web.Mvc;
using System.Configuration;

namespace LUB4C.Tests.Controllers
{
    [TestClass]
    public class ValuesControllerTest
    {
        private string maestroURI { get; set; }
        private string maestroModel { get; set; }
        private string maestroEntity { get; set; }
        private string maestroVersion { get; set; }
        private string maestroStrategy { get; set; }

        [TestInitialize]
        public void TestInitialize()
        {
            maestroURI = ConfigurationManager.AppSettings.Get("MaestroURI");
            maestroModel = ConfigurationManager.AppSettings.Get("MaestroModel");
            maestroEntity = ConfigurationManager.AppSettings.Get("MaestroEntity");
            maestroStrategy = ConfigurationManager.AppSettings.Get("MaestroStrategy");
            maestroVersion = ConfigurationManager.AppSettings.Get("MaestroVersion");
        }

        [TestMethod()]
        public void MatchRequestAccount_ValuesGet()
        {
            MatchRequest matchRequest = new MatchRequest();
            matchRequest.requestIdentifier = "lookup";

            matchRequest.search = new LookupSearch() { model = maestroModel, entity = maestroEntity, strategy = maestroStrategy, version = maestroVersion };

            matchRequest.columns = new List<LookupColumn>();
            matchRequest.columns.Add(new LookupColumn() { name = "Name", value = "GenePoint" });
            matchRequest.columns.Add(new LookupColumn() { name = "Billing Address", value = "345 Shoreline Park" });
            matchRequest.columns.Add(new LookupColumn() { name = "Billing City", value = "Mountain View" });
            matchRequest.columns.Add(new LookupColumn() { name = "Billing Postal Code", value = "94043" });

            string requestString = JsonConvert.SerializeObject(matchRequest, Newtonsoft.Json.Formatting.None);

            ValuesController controller = new ValuesController();
            JsonResult result = controller.Get(requestString);
        }

        [TestMethod()]
        public void TriggerRequestAccount_ValuesGet()
        {
            MatchRequest triggerRequest = new MatchRequest();
            triggerRequest.requestIdentifier = "trigger";
            triggerRequest.search = new LookupSearch() { model = "Customer", entity = "Customer", strategy = "SF Account LUB4C", version = "Version_1" };
            triggerRequest.columns = new List<LookupColumn>();
            triggerRequest.columns.Add(new LookupColumn() { name = "Name", value = "Ace Office Supply" });
            triggerRequest.columns.Add(new LookupColumn() { name = "SalesforceID", value = "001i0000025JxlkAAD" });

            string requestString = JsonConvert.SerializeObject(triggerRequest, Newtonsoft.Json.Formatting.None);

            ValuesController controller = new ValuesController();
            JsonResult result = controller.Get(requestString);
        }
    }
}
