﻿using System.Web.Mvc;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using LUB4C;
using LUB4C.Controllers;
using LUB4C.Models;
using Newtonsoft.Json;
using System.Collections.Generic;
using Profisee.MasterDataMaestro.Services.DataContracts.MasterDataServices;

namespace LUB4C.Tests.Controllers
{
    [TestClass]
    public class HomeControllerTest
    {
        [TestMethod]
        public void Index()
        {
            // Arrange
            HomeController controller = new HomeController();

            // Act
            ViewResult result = controller.Index() as ViewResult;

            // Assert
            Assert.IsNotNull(result);
            Assert.AreEqual("Home Page", result.ViewBag.Title);
        }

        [TestMethod()]
        public void Get_AjaxHandlerLookupAccount()
        {
            MatchRequest matchRequest = new MatchRequest();
            matchRequest.requestIdentifier = "fieldRequestIdentifier";
            matchRequest.search = new LookupSearch() { model = "Salesforce", entity = "Account", strategy = "Salesforce Account", version = "VERSION_1" };
            matchRequest.columns = new List<LookupColumn>();
            matchRequest.columns.Add(new LookupColumn() { name = "Name", value = "First Financial" });
            matchRequest.columns.Add(new LookupColumn() { name = "Billing Address", value = "255 East Fifth Street" });
            matchRequest.columns.Add(new LookupColumn() { name = "Billing City", value = "" });
            matchRequest.columns.Add(new LookupColumn() { name = "Billing Postal Code", value = "45202" });

            string requestString = JsonConvert.SerializeObject(matchRequest, Newtonsoft.Json.Formatting.None);

            HomeController controller = new HomeController();

            ActionResult result = controller.AjaxHandler_Lookup(requestString);
        }

        [TestMethod()]
        public void Get_AjaxHandlerLookupContact()
        {
            MatchRequest matchRequest = new MatchRequest();
            matchRequest.requestIdentifier = "fieldRequestIdentifier";
            matchRequest.search = new LookupSearch() { model = "Salesforce", entity = "Contact", strategy = "Salesforce Contact", version = "VERSION_1" };
            matchRequest.columns = new List<LookupColumn>();
            matchRequest.columns.Add(new LookupColumn() { name = "Last Name", value = "Emberly" });

            string requestString = JsonConvert.SerializeObject(matchRequest, Newtonsoft.Json.Formatting.None);

            HomeController controller = new HomeController();

            ActionResult result = controller.AjaxHandler_Lookup(requestString);
        }

    }
}
